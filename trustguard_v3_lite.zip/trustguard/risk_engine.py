"""TrustGuard risk engine (LITE build: numpy + pandas only, no scikit-learn / scipy).

Three layers, all explainable:
  1. Weighted rules          -> human-readable reasons + points
  2. Isolation Forest (ML)   -> catches 'weird but not in any rule' orders, with top-feature explanations
  3. Fraud-ring graph        -> links accounts that secretly share devices / cards
Rule weights are *learnable*: analyst feedback nudges them (see app.py).
"""
import re

import numpy as np
import pandas as pd

HOLD, BLOCK = 50, 75
W_MIN, W_MAX = 5.0, 45.0

# id -> (condition, default points, reason text)
RULES = {
    "new_acct":  (lambda o: o["account_age_hrs"] < 1 and o["amount"] > 10000, 35,
                  lambda o: "New account (<1 hr old) placing a high-value order"),
    "geo":       (lambda o: o["bill_state"] != o["ship_state"], 20,
                  lambda o: f"Billing ({o['bill_state']}) and shipping ({o['ship_state']}) are in different states"),
    "velocity":  (lambda o: o["orders_10min"] >= 3, 25,
                  lambda o: f"{int(o['orders_10min'])} orders placed within 10 minutes"),
    "card":      (lambda o: o["card_flags"] >= 1, 20,
                  lambda o: "Payment method flagged in earlier sessions"),
    "big":       (lambda o: o["amount"] > 25000, 10,
                  lambda o: "Unusually large order amount"),
    "ring":      (lambda o: o["ring_size"] >= 3, 30,
                  lambda o: f"Linked to a {int(o['ring_size'])}-account fraud ring ({o['ring_id']}) via shared device/card"),
    # --- dormant "patch" rules: weight 0 until the Red/Blue Team agent proves they help and deploys them ---
    "young_acct":   (lambda o: o["account_age_hrs"] < 24 and o["amount"] > 5000, 0,
                     lambda o: f"Account only {o['account_age_hrs']:.0f}h old with an order above ₹5,000"),
    "hv_geo":       (lambda o: o["amount"] > 15000 and o["bill_state"] != o["ship_state"], 0,
                     lambda o: f"High-value order (₹{int(o['amount']):,}) shipped to a different state"),
    "geo_mid":      (lambda o: o["amount"] > 5000 and o["bill_state"] != o["ship_state"], 0,
                     lambda o: "Mid-value order shipped to a different state"),
    "shared_dev":   (lambda o: o["device_accts"] >= 2, 0,
                     lambda o: f"Device shared by {int(o['device_accts'])} different accounts"),
    "card_testing": (lambda o: o["orders_10min"] >= 5, 0,
                     lambda o: f"Card-testing burst: {int(o['orders_10min'])} orders in 10 minutes"),
    "ml":        (lambda o: o["ml_pct"] >= 0.95, 15,
                  lambda o: f"ML outlier (top {max(1, round((1 - o['ml_pct']) * 100))}% most unusual): {o['ml_note']}"),
}
DEFAULT_WEIGHTS = {k: float(v[1]) for k, v in RULES.items()}
RULE_NAMES = {"new_acct": "New account + big order", "geo": "State mismatch", "velocity": "Order burst",
              "card": "Flagged card", "big": "Large amount", "ring": "Fraud-ring link", "ml": "ML outlier",
              "young_acct": "[patch] Young account", "hv_geo": "[patch] High-value geo mismatch",
              "geo_mid": "[patch] Mid-value geo mismatch", "shared_dev": "[patch] Shared device",
              "card_testing": "[patch] Card-testing burst"}



# ---------------------------------------------------------------- numpy-only building blocks
class IsoForest:
    """Isolation Forest written from scratch in numpy (same algorithm as scikit-learn's).
    Anomalies are 'easy to isolate': random splits separate them in few steps -> short path -> high score."""

    def __init__(self, n_trees=60, sample=256, seed=7):
        self.n_trees, self.sample, self.seed = n_trees, sample, seed

    @staticmethod
    def _c(n):  # average path length of an unsuccessful search in a binary tree
        return 0.0 if n <= 1 else 2.0 * (np.log(n - 1) + 0.5772156649) - 2.0 * (n - 1) / n

    def fit(self, X):
        rng = np.random.default_rng(self.seed)
        self.psi = min(self.sample, len(X))
        self.max_depth = int(np.ceil(np.log2(max(self.psi, 2))))
        self.trees = [self._build(X[rng.choice(len(X), self.psi, replace=False)], rng) for _ in range(self.n_trees)]
        return self

    def _build(self, S, rng):
        feat, thr, left, right, size = [], [], [], [], []

        def node(rows, depth):
            i = len(feat)
            feat.append(-1); thr.append(0.0); left.append(-1); right.append(-1); size.append(len(rows))
            if depth >= self.max_depth or len(rows) <= 1:
                return i
            lo, hi = rows.min(0), rows.max(0)
            cand = np.where(hi > lo)[0]
            if len(cand) == 0:
                return i
            f = int(rng.choice(cand))
            t = rng.uniform(lo[f], hi[f])
            mask = rows[:, f] < t
            feat[i], thr[i] = f, t
            left[i] = node(rows[mask], depth + 1)
            right[i] = node(rows[~mask], depth + 1)
            return i

        node(S, 0)
        return (np.array(feat), np.array(thr), np.array(left), np.array(right),
                np.array([self._c(n) for n in size]))

    def _depths(self, tree, X):
        feat, thr, left, right, cadj = tree
        node, depth, rows = np.zeros(len(X), dtype=int), np.zeros(len(X)), np.arange(len(X))
        for _ in range(self.max_depth + 1):
            f = feat[node]
            internal = f >= 0
            if not internal.any():
                break
            go_left = X[rows, np.where(internal, f, 0)] < thr[node]
            node = np.where(internal, np.where(go_left, left[node], right[node]), node)
            depth = depth + internal
        return depth + cadj[node]

    def score(self, X):
        """Anomaly score in (0, 1): higher = more unusual."""
        X = np.asarray(X, dtype=float)
        h = np.mean([self._depths(t, X) for t in self.trees], axis=0)
        return 2.0 ** (-h / self._c(self.psi))


def tfidf_cosine(texts):
    """Pairwise cosine similarity of TF-IDF vectors, numpy only."""
    docs = [re.findall(r"\b\w\w+\b", t.lower()) for t in texts]
    vocab = {w: i for i, w in enumerate(sorted({w for d in docs for w in d}))}
    tf = np.zeros((len(docs), len(vocab)))
    for r, d in enumerate(docs):
        for w in d:
            tf[r, vocab[w]] += 1
    idf = np.log((1 + len(docs)) / (1 + (tf > 0).sum(0))) + 1
    X = tf * idf
    norm = np.linalg.norm(X, axis=1, keepdims=True)
    X = X / np.where(norm == 0, 1, norm)
    return X @ X.T


# ---------------------------------------------------------------- ML anomaly layer
class Detector:
    """Isolation Forest trained on 'normal' baseline traffic. Gives a percentile + top reasons per order."""
    FEATS = ["log_amount", "log_age", "orders_10min", "card_flags", "state_mismatch"]

    def __init__(self, baseline: pd.DataFrame):
        X = self._X(baseline)
        self.iso = IsoForest().fit(X.to_numpy())
        self.ref = np.sort(self.iso.score(X.to_numpy()))
        self.med = X.median()
        mad = (X - self.med).abs().median() * 1.4826
        self.scale = mad.where(mad > 0, X.std().replace(0, 1.0)).fillna(1.0)
        self.med_amount = float(baseline["amount"].median())

    @classmethod
    def _X(cls, df):
        return pd.DataFrame({
            "log_amount": np.log1p(df["amount"].astype(float)),
            "log_age": np.log1p(df["account_age_hrs"].astype(float)),
            "orders_10min": df["orders_10min"].astype(float),
            "card_flags": df["card_flags"].astype(float),
            "state_mismatch": (df["bill_state"] != df["ship_state"]).astype(float),
        })[cls.FEATS]

    def annotate(self, df):
        out = df.copy()
        X = self._X(out)
        s = self.iso.score(X.to_numpy())
        out["ml_pct"] = np.searchsorted(self.ref, s) / len(self.ref)
        z = (X - self.med) / self.scale
        z["log_age"] = -z["log_age"]  # a *young* account is the unusual direction
        notes = []
        for (_, zr), o in zip(z.iterrows(), out.to_dict("records")):
            top = [f for f in zr.sort_values(ascending=False).index[:2] if zr[f] > 1.5]
            notes.append(", ".join(self._phrase(f, o) for f in top) or "unusual combination of signals")
        out["ml_note"] = notes
        return out

    def _phrase(self, f, o):
        return {"log_amount": f"amount ₹{int(o['amount']):,} is {o['amount'] / self.med_amount:.1f}× typical",
                "log_age": f"account only {o['account_age_hrs']:.1f}h old",
                "orders_10min": f"{int(o['orders_10min'])} orders in 10 min",
                "card_flags": "card flagged before",
                "state_mismatch": "billing ≠ shipping state"}[f]


# ---------------------------------------------------------------- fraud-ring graph
def find_rings(df, min_accounts=3):
    """Union-find over account/device/card nodes. A connected group with >=3 accounts is a ring."""
    parent = {}

    def find(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for a, d, c in zip(df["account_id"], df["device_id"], df["card_id"]):
        for other in (("d", d), ("c", c)):
            ra, rb = find(("a", a)), find(other)
            if ra != rb:
                parent[ra] = rb
    root = [find(("a", a)) for a in df["account_id"]]
    out = df.copy()
    out["_root"] = root
    sizes = out.groupby("_root")["account_id"].nunique()
    out["ring_size"] = out["_root"].map(sizes).astype(int)
    big = sizes[sizes >= min_accounts].sort_values(ascending=False)
    names = {r: f"R{i + 1}" for i, r in enumerate(big.index)}
    out["ring_id"] = out["_root"].map(names).fillna("")
    out["ring_key"] = out.groupby("_root")["device_id"].transform("min")  # stable id: survives re-ranking
    out["device_accts"] = out.groupby("device_id")["account_id"].transform("nunique").astype(int)
    out.loc[out["ring_size"] < min_accounts, ["ring_size", "ring_key"]] = [0, ""]
    return out.drop(columns="_root")


def ring_dot(df, ring_id):
    """Graphviz DOT source for one ring: accounts (red = blocked) linked to shared devices/cards."""
    sub = df[df["ring_id"] == ring_id].drop_duplicates("account_id")
    lines = ['graph G { bgcolor="transparent"; layout=neato; overlap=false; splines=true;',
             'node [fontcolor="white", fontsize=9, style=filled, color="#333333"];']
    for _, r in sub.iterrows():
        col = "#e5484d" if r["risk"] >= BLOCK else "#f5a623" if r["risk"] >= HOLD else "#4c9f70"
        lines.append(f'"{r["account_id"]}" [shape=ellipse, fillcolor="{col}", label="{r["account_id"][5:]}"];')
        lines.append(f'"{r["device_id"]}" [shape=box, fillcolor="#3b6fd4", label="📱 {r["device_id"][4:]}"];')
        lines.append(f'"{r["card_id"]}" [shape=diamond, fillcolor="#8e4ec6", label="💳 {r["card_id"][5:]}"];')
        lines.append(f'"{r["account_id"]}" -- "{r["device_id"]}" [color="#888888"];')
        lines.append(f'"{r["account_id"]}" -- "{r["card_id"]}" [color="#888888"];')
    return "\n".join(lines) + "\n}"


# ---------------------------------------------------------------- scoring
def action_for(score):
    return "Block + manual review" if score >= BLOCK else "Hold for review" if score >= HOLD else "Approve"


def score_order(o, weights):
    hits = [(text(o), weights[k], k) for k, (cond, _, text) in RULES.items()
            if weights.get(k, 0) > 0 and cond(o)]
    score = int(min(100, round(sum(p for _, p, _ in hits))))
    return score, hits, action_for(score)


def score_frame(df, det, weights):
    """Annotate with ML + score every row. `df` must already have ring_id / ring_size."""
    return rescore(det.annotate(df), weights)


def rescore(out, weights):
    """Apply the rules to an already-annotated frame (cheap: lets agents test many weight sets fast)."""
    out = out.copy()
    res = [score_order(r, weights) for r in out.to_dict("records")]
    out["risk"] = [r[0] for r in res]
    out["reasons"] = [r[1] for r in res]
    out["action"] = [r[2] for r in res]
    out["why"] = ["; ".join(t for t, _, _ in h) for h in out["reasons"]]
    return out


def analyze(orders, det, weights):
    return score_frame(find_rings(orders), det, weights)


def counterfactual(score, hits):
    """Smallest set of signals that, if absent, would drop the order below the review threshold."""
    if score < HOLD:
        return []
    need, left = [], score
    for text, pts, _ in sorted(hits, key=lambda h: -h[1]):
        need.append((text, pts))
        left -= pts
        if left < HOLD:
            break
    return need


# ---------------------------------------------------------------- fake reviews
def flag_reviews(df, threshold=0.85):
    """Near-duplicate text (TF-IDF cosine) + posting burst + brand-new accounts -> review risk, grouped into campaigns."""
    sim = tfidf_cosine(list(df["text"]))
    np.fill_diagonal(sim, 0)
    out = df.copy().reset_index(drop=True)
    out["similar_reviews"] = (sim > threshold).sum(axis=1)
    risk, reason = [], []
    for n, m, age in zip(out["similar_reviews"], out["minutes_ago"], out["acct_age_days"]):
        parts, pts = [], 0
        if n >= 2:
            pts += 50
            parts.append(f"text nearly identical to {n} other reviews")
            if m <= 20:
                pts += 25
                parts.append("posted in a 20-min burst")
            if age < 3:
                pts += 25
                parts.append(f"account only {age}d old")
        risk.append(pts)
        reason.append("; ".join(parts))
    out["risk"], out["reason"] = risk, reason
    out["suspicious"] = out["risk"] >= 50

    # group suspicious reviews into coordinated "campaigns"
    idx = list(out.index[out["suspicious"]])
    camp, cid = {}, 0
    for i in idx:
        if i in camp:
            continue
        cid += 1
        stack = [i]
        while stack:
            u = stack.pop()
            if u in camp:
                continue
            camp[u] = cid
            stack += [v for v in idx if v not in camp and sim[u, v] > threshold]
    out["campaign"] = [f"C{camp[i]}" if i in camp else "" for i in out.index]
    return out

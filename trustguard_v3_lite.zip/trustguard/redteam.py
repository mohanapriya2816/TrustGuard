"""Red Team vs Blue Team agent.

RED  invents evasion attacks designed to slip under the current rules.
BLUE tests candidate patch rules against those attacks AND against normal traffic,
     recommends only patches that catch more fraud without flooding analysts with false alarms.
"""
import random
from datetime import datetime

import numpy as np
import pandas as pd

from data_gen import STATE_LIST, make_orders
from risk_engine import HOLD, RULE_NAMES, find_rings, rescore

PATCH_WEIGHT = 50.0   # enough to trigger manual review on its own, never an auto-block
PATCHES = ["young_acct", "hv_geo", "geo_mid", "shared_dev", "card_testing"]
FP_LIMIT = 0.01       # a patch may flag at most +1% extra normal orders
MIN_UPLIFT = 0.25

STRATEGIES = {
    "Obvious attack (control)": "Brand-new account, huge order, mismatched addresses — what v1 already catches.",
    "Slow drip": "Fresh accounts, orders kept just under ₹10k, same state, one at a time.",
    "Aged-account takeover": "Hijacked old accounts shipping ₹15–30k to a different state.",
    "Device pairs": "Two accounts per device so no big ring forms; modest amounts.",
    "Card-testing burst": "Tiny orders, 6–10 in 10 minutes, on young accounts.",
}


def _base(i, rnd, **kw):
    st_ = rnd.choice(STATE_LIST)
    row = dict(order_id=900000 + i, account_id=f"acct_rt{i}", account_age_hrs=24.0, amount=1000,
               bill_state=st_, ship_state=st_, orders_10min=1, card_flags=0, created_at=datetime.now(),
               device_id=f"dev_rt{i}", card_id=f"card_rt{i}", is_fraud=True)
    row.update(kw)
    return row


def gen(strategy, n, seed):
    rnd = random.Random(seed)
    rows = []
    for i in range(n):
        other = lambda s: rnd.choice([x for x in STATE_LIST if x != s])
        if strategy.startswith("Obvious"):
            r = _base(i, rnd, account_age_hrs=round(rnd.uniform(0.1, 3), 1), amount=rnd.randint(12000, 60000),
                      orders_10min=rnd.randint(1, 5), card_flags=rnd.choice([0, 1, 2]))
            r["ship_state"] = other(r["bill_state"])
        elif strategy == "Slow drip":
            r = _base(i, rnd, account_age_hrs=round(rnd.uniform(2, 6), 1), amount=rnd.randint(6000, 9900))
        elif strategy == "Aged-account takeover":
            r = _base(i, rnd, account_age_hrs=rnd.randint(200, 2000), amount=rnd.randint(15000, 30000),
                      orders_10min=rnd.randint(1, 2))
            r["ship_state"] = other(r["bill_state"])
        elif strategy == "Device pairs":
            r = _base(i, rnd, account_age_hrs=round(rnd.uniform(4, 30), 1), amount=rnd.randint(9000, 14000),
                      orders_10min=rnd.randint(1, 2), device_id=f"dev_rtpair{i // 2}", card_id=f"card_rtpair{i // 2}")
        else:  # Card-testing burst
            r = _base(i, rnd, account_age_hrs=round(rnd.uniform(3, 10), 1), amount=rnd.randint(300, 900),
                      orders_10min=rnd.randint(6, 10))
        rows.append(r)
    return pd.DataFrame(rows)


def _rates(frames, weights):
    return {name: float((rescore(df, weights)["risk"] >= HOLD).mean()) for name, df in frames.items()}


def drill(det, weights, n=40, seed=None):
    """Run the full red-vs-blue drill. Returns results dict (no side effects)."""
    seed = seed if seed is not None else random.randint(1, 10**6)
    frames = {s: det.annotate(find_rings(gen(s, n, seed))) for s in STRATEGIES}
    normal = make_orders(500, fraud_rate=0, seed=11)
    normal = det.annotate(find_rings(normal))
    fp_base = float((rescore(normal, weights)["risk"] >= HOLD).mean())
    before = _rates(frames, weights)

    patches, chosen = [], dict(weights)
    for rule in PATCHES:
        if weights.get(rule, 0) > 0:
            continue  # already deployed
        w2 = {**weights, rule: PATCH_WEIGHT}
        after = _rates(frames, w2)
        gain = {s: after[s] - before[s] for s in STRATEGIES if not s.startswith("Obvious")}
        uplift = sum(max(0, g) for g in gain.values())
        fp = float((rescore(normal, w2)["risk"] >= HOLD).mean()) - fp_base
        best = max(gain, key=gain.get)
        ok = uplift >= MIN_UPLIFT and fp <= FP_LIMIT
        why = ("catches more fraud with no meaningful false-alarm cost" if ok else
               f"false alarms +{fp:.1%} exceed the {FP_LIMIT:.0%} limit" if fp > FP_LIMIT else
               "does not close a meaningful gap")
        patches.append(dict(rule=rule, name=RULE_NAMES[rule], best_for=best, uplift=uplift, fp_delta=fp,
                            recommended=ok, why=why))
        if ok:
            chosen[rule] = PATCH_WEIGHT
    after_all = _rates(frames, chosen)
    fp_after = float((rescore(normal, chosen)["risk"] >= HOLD).mean())
    return dict(before=before, after=after_all, patches=patches, fp_before=fp_base, fp_after=fp_after,
                strategies=STRATEGIES)

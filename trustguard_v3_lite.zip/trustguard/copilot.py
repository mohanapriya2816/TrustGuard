"""Analyst co-pilot: plain-English case notes. Uses Claude if ANTHROPIC_API_KEY is set, else a built-in template."""
import os


def facts(row):
    lines = [f"Order #{row['order_id']} | risk {row['risk']}/100 | action: {row['action']}",
             f"Amount ₹{int(row['amount']):,} | account age {row['account_age_hrs']}h | "
             f"billing {row['bill_state']} -> shipping {row['ship_state']}"]
    lines += [f"- {t} (+{p:.0f})" for t, p, _ in row["reasons"]]
    return "\n".join(lines)


def template_note(row):
    keys = {k for _, _, k in row["reasons"]}
    steps = []
    if "ring" in keys:
        steps.append(f"freeze every account in ring {row['ring_id']} (see Fraud Rings tab)")
    if "new_acct" in keys:
        steps.append("require step-up verification (OTP / KYC) before release")
    if "card" in keys:
        steps.append("contact the card issuer about prior flags")
    if "velocity" in keys:
        steps.append("rate-limit this account and device")
    steps = steps or ["approve, but keep monitoring"]
    top = "; ".join(t for t, _, _ in sorted(row["reasons"], key=lambda r: -r[1])[:2]) or "no strong signals"
    return (f"Order #{row['order_id']} scored {row['risk']}/100 ({row['action']}). Main drivers: {top}. "
            f"Suggested next steps: {', '.join(steps)}.")


def ai_available():
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def case_note(row):
    """Returns (text, source). Falls back to the template if the API is unavailable."""
    if ai_available():
        try:
            import anthropic
            msg = anthropic.Anthropic().messages.create(
                model=os.environ.get("TRUSTGUARD_MODEL", "claude-sonnet-4-6"), max_tokens=300,
                messages=[{"role": "user", "content":
                           "You are a fraud analyst co-pilot. From ONLY these facts, write a 3-sentence case note "
                           "for a human reviewer: what happened, how confident we should be, and the next 2 steps. "
                           "Do not invent facts.\n\n" + facts(row)}])
            return msg.content[0].text.strip(), "Claude"
        except Exception:
            pass
    return template_note(row), "template"

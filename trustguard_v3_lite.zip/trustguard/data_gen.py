"""Synthetic data: orders (with organised fraud rings hidden inside) and reviews (with a bot campaign)."""
import random
import pandas as pd
from datetime import datetime, timedelta

# state -> (lat, lon) so we can draw an attack map
STATES = {"TN": (11.1, 78.7), "KA": (15.3, 75.7), "MH": (19.7, 75.7),
          "DL": (28.6, 77.2), "KL": (10.5, 76.3), "AP": (15.9, 79.7)}
STATE_LIST = list(STATES)

# Three pre-existing fraud rings: each shares a few devices and cards across MANY accounts.
RINGS = [dict(devices=[f"dev_ring{r}_{i}" for i in range(2)],
              cards=[f"card_ring{r}_{i}" for i in range(3)]) for r in range(3)]


def _order(oid, fraud, ts, rnd, ring=None):
    state = rnd.choice(STATE_LIST)
    acct = f"acct_{rnd.randint(100000, 999999)}"
    if fraud:  # new account, big amount, odd patterns
        row = dict(order_id=oid, account_id=acct, account_age_hrs=round(rnd.uniform(0.1, 3), 1),
                   amount=rnd.randint(12000, 60000), bill_state=state,
                   ship_state=rnd.choice(STATE_LIST), orders_10min=rnd.randint(1, 5),
                   card_flags=rnd.choice([0, 1, 2]), created_at=ts)
    else:
        row = dict(order_id=oid, account_id=acct, account_age_hrs=rnd.randint(48, 9000),
                   amount=rnd.randint(200, 9000), bill_state=state,
                   ship_state=state if rnd.random() < 0.93 else rnd.choice(STATE_LIST),
                   orders_10min=1, card_flags=0, created_at=ts)
    row["is_fraud"] = bool(fraud)  # synthetic ground truth (for the precision/recall scorecard)
    ring = ring or (None if not fraud or rnd.random() > 0.7 else rnd.choice(RINGS))
    row["device_id"] = rnd.choice(ring["devices"]) if ring else f"dev_{rnd.randint(1, 10**7)}"
    row["card_id"] = rnd.choice(ring["cards"]) if ring else f"card_{rnd.randint(1, 10**7)}"
    return row


def make_orders(n=600, fraud_rate=0.12, seed=7):
    rnd = random.Random(seed)
    now = datetime.now()
    return pd.DataFrame([_order(48000 + i, rnd.random() < fraud_rate,
                                now - timedelta(minutes=rnd.randint(0, 600)), rnd) for i in range(n)])


def new_orders(start_id, n=2, fraud_rate=0.15):
    """A few fresh orders 'arriving right now' for the live stream."""
    rnd = random.Random()
    now = datetime.now()
    return pd.DataFrame([_order(start_id + i, rnd.random() < fraud_rate, now, rnd) for i in range(n)])


def attack_orders(start_id, k=15):
    """Simulates a coordinated card-testing attack: a NEW ring (fresh devices + cards) hits at once."""
    rnd = random.Random()
    tag = rnd.randint(100, 999)
    ring = dict(devices=[f"dev_atk{tag}_{i}" for i in range(2)], cards=[f"card_atk{tag}_{i}" for i in range(3)])
    now = datetime.now()
    rows = []
    for i in range(k):
        o = _order(start_id + i, True, now - timedelta(seconds=rnd.randint(0, 90)), rnd, ring=ring)
        o.update(orders_10min=rnd.randint(3, 6), card_flags=rnd.choice([1, 2]))
        rows.append(o)
    return pd.DataFrame(rows)


A = ["Battery lasts long,", "Camera is decent,", "Fabric feels thin,", "Sound quality is good,",
     "Packaging was damaged,", "Build feels solid,", "Colour differs from photos,", "Setup was easy,",
     "Delivery was late,", "Size runs small,"]
B = ["but the price is fair.", "though customer care replied slowly.", "and it works as described.",
     "however the manual is confusing.", "so I kept it.", "but I returned it.",
     "and my family likes it.", "though it heats up a bit.", "and it fits well.", "but it feels overpriced."]


def make_reviews(n_real=60, n_fake=14, seed=3):
    rnd = random.Random(seed)
    rows = [dict(review_id=i, account=f"user{rnd.randint(100, 999)}",
                 text=f"{rnd.choice(A)} {rnd.choice(B)} Used it {rnd.randint(2, 90)} days.",
                 minutes_ago=rnd.randint(60, 5000), acct_age_days=rnd.randint(30, 2000)) for i in range(n_real)]
    for j in range(n_fake):  # templated bot reviews, posted in a burst from brand-new accounts
        rows.append(dict(review_id=1000 + j, account=f"new_acct_{j}",
                         text="Amazing product, totally worth the money, five stars, "
                              f"highly recommend to everyone{rnd.choice(['!!', '!', '', '!!!'])}",
                         minutes_ago=rnd.randint(0, 20), acct_age_days=rnd.randint(0, 2)))
    return pd.DataFrame(rows)

"""TrustGuard agent squad.

  🧭 Triage Agent      – decides on flagged orders (auto-block / queue for a human)
  🕸️ Ring Hunter       – proposes or executes freezing of whole fraud rings
  📝 Review Guardian   – proposes takedown of bot-review campaigns (always needs a human)
  🔬 Investigator      – tool-using agent that builds a case file with a visible reasoning trace
  💬 Ask TrustGuard    – chat over live data (same tools)
  ⚔️ Red/Blue Team     – see redteam.py

Every agent works WITHOUT an LLM (deterministic planners), and upgrades to live Claude tool-use
when ANTHROPIC_API_KEY is set. Autonomy is bounded by guardrails (confidence, rate limit, value cap).
"""
import json
import os
import re
import urllib.request
from datetime import datetime

import pandas as pd

import copilot
from risk_engine import BLOCK, HOLD, RULE_NAMES, counterfactual, score_frame

AGENTS = {"triage": "🧭 Triage Agent", "ring": "🕸️ Ring Hunter", "guardian": "📝 Review Guardian",
          "investigator": "🔬 Investigator", "chat": "💬 Ask TrustGuard", "red": "⚔️ Red/Blue Team"}
FAMILY = {"new_acct": "identity", "young_acct": "identity", "geo": "geo", "hv_geo": "geo", "geo_mid": "geo",
          "velocity": "behavior", "card_testing": "behavior", "card": "payment", "big": "amount",
          "ring": "network", "shared_dev": "network", "ml": "anomaly"}
DEFAULT_GUARD = dict(min_conf=0.85, max_auto=10, ring_cap=1_000_000)
_DROP = ["reasons", "action", "why", "risk", "ml_pct", "ml_note", "status"]


# ------------------------------------------------------------------ shared helpers
def init_state(S):
    S.handled, S.frozen, S.takedowns = {}, set(), set()
    S.proposed, S.queue, S.next_pid = set(), [], 1
    S.agent_log, S.chat = [], []
    S.guard = dict(DEFAULT_GUARD)
    S.mode, S.redteam, S.investigation = "Off", None, None


def log_agent(S, agent, action, target, detail, conf=None):
    S.agent_log.append(dict(time=datetime.now().strftime("%H:%M:%S"), agent=AGENTS[agent], action=action,
                            target=target, confidence=conf, detail=detail))


def notify(text):
    """Optional Slack alert: set SLACK_WEBHOOK_URL. Silent no-op otherwise."""
    url = os.environ.get("SLACK_WEBHOOK_URL")
    if not url:
        return
    try:
        req = urllib.request.Request(url, json.dumps({"text": f"🛡️ TrustGuard: {text}"}).encode(),
                                     {"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=3)
    except Exception:
        pass


def confidence(row):
    """More independent signal families agreeing + higher score => higher confidence."""
    fams = {FAMILY.get(k, k) for _, _, k in row["reasons"]}
    return round(min(0.99, 0.55 * row["risk"] / 100 + 0.11 * len(fams)), 2)


def _propose(S, agent, kind, key, title, detail, conf, amount=0):
    S.proposed.add((kind, key))
    S.queue.append(dict(id=S.next_pid, agent=agent, kind=kind, key=key, title=title, detail=detail,
                        conf=conf, amount=amount, status="pending"))
    S.next_pid += 1


def pending(S):
    return [p for p in S.queue if p["status"] == "pending"]


def with_status(df, S):
    queued = {p["key"] for p in pending(S) if p["kind"] == "order"}
    out = []
    for oid, key in zip(df["order_id"], df["ring_key"]):
        out.append(S.handled.get(int(oid)) or
                   {"fraud": "analyst: confirmed fraud", "fp": "analyst: false positive"}.get(S.decisions.get(oid), "")
                   or ("blocked: ring frozen" if key and key in S.frozen else "")
                   or ("⏳ awaiting approval" if int(oid) in queued else ""))
    df = df.copy()
    df["status"] = out
    return df


def execute(S, prop, approve):
    """Human decision on a queued proposal."""
    prop["status"] = "approved" if approve else "rejected"
    who = "human-approved" if approve else "human-rejected"
    if prop["kind"] == "order":
        S.handled[prop["key"]] = f"blocked ({who})" if approve else "released (human)"
    elif prop["kind"] == "ring" and approve:
        S.frozen.add(prop["key"])
    elif prop["kind"] == "campaign" and approve:
        S.takedowns.add(prop["key"])
    log_agent(S, prop["agent"], who, prop["title"], prop["detail"], prop["conf"])


# ------------------------------------------------------------------ autonomous agents
def triage_sweep(df, S, mode):
    g = S.guard
    n_auto = n_prop = n_amb = throttled = 0
    flagged = df[df["risk"] >= HOLD].sort_values("risk", ascending=False)
    for r in flagged.to_dict("records"):
        oid = int(r["order_id"])
        if oid in S.handled or oid in S.decisions or ("order", oid) in S.proposed:
            continue
        if r["ring_key"] and r["ring_key"] in S.frozen:
            S.handled[oid] = "blocked: ring frozen"
            continue
        conf = confidence(r)
        top = "; ".join(t for t, _, _ in sorted(r["reasons"], key=lambda x: -x[1])[:2])
        if conf >= g["min_conf"]:
            if mode == "Autopilot":
                if n_auto < g["max_auto"]:
                    S.handled[oid] = "blocked by Triage Agent"
                    n_auto += 1
                    log_agent(S, "triage", "auto-blocked", f"order #{oid} (₹{int(r['amount']):,})", top, conf)
                else:
                    throttled += 1
            elif n_prop < 8 and len(pending(S)) < 25:
                _propose(S, "triage", "order", oid, f"Block order #{oid} (₹{int(r['amount']):,})",
                         top, conf, r["amount"])
                n_prop += 1
        elif n_amb < 3 and len(pending(S)) < 25:
            _propose(S, "triage", "order", oid, f"Judgment call: order #{oid} (risk {r['risk']})",
                     "Signals disagree — " + top, conf, r["amount"])
            n_amb += 1
    if throttled:
        log_agent(S, "triage", "circuit breaker", f"{throttled} orders held back",
                  f"Rate limit of {g['max_auto']} auto-actions per sweep reached; remainder waits for next sweep")
    if n_auto >= 3:
        notify(f"Triage Agent auto-blocked {n_auto} orders.")


def ring_sweep(df, S, mode):
    g = S.guard
    rings = df[df["ring_key"] != ""].groupby("ring_key").agg(
        ring_id=("ring_id", "first"), accounts=("account_id", "nunique"), orders=("order_id", "size"),
        value=("amount", "sum"), avg_risk=("risk", "mean"))
    for key, r in rings.iterrows():
        if key in S.frozen or ("ring", key) in S.proposed:
            continue
        conf = round(min(0.99, r["avg_risk"] / 100 * 0.7 + 0.03 * min(r["accounts"], 10)), 2)
        title = f"Freeze ring {r['ring_id']} ({int(r['accounts'])} accounts, ₹{int(r['value']):,})"
        detail = f"{int(r['orders'])} orders linked by shared devices/cards; avg risk {r['avg_risk']:.0f}"
        if mode == "Autopilot" and conf >= g["min_conf"] and r["value"] <= g["ring_cap"]:
            S.frozen.add(key)
            S.proposed.add(("ring", key))
            log_agent(S, "ring", "auto-froze ring", title, detail, conf)
            notify(f"Ring Hunter auto-froze {title}")
        elif len(pending(S)) < 25:
            if mode == "Autopilot" and r["value"] > g["ring_cap"]:
                detail += f" — exceeds the ₹{g['ring_cap']:,} autonomous cap, human sign-off required"
            _propose(S, "ring", "ring", key, title, detail, conf, r["value"])


def guardian_sweep(reviews, S, mode):
    bad = reviews[reviews["campaign"] != ""]
    for camp, grp in bad.groupby("campaign"):
        if camp in S.takedowns or ("campaign", camp) in S.proposed:
            continue
        _propose(S, "guardian", "campaign", camp, f"Remove bot campaign {camp} ({len(grp)} reviews)",
                 f"{grp['account'].nunique()} accounts, avg age {grp['acct_age_days'].mean():.1f} days; "
                 "content removal always needs a human", 0.97)


def run_all(df, reviews, S):
    if S.mode == "Off":
        return
    triage_sweep(df, S, S.mode)
    ring_sweep(df, S, S.mode)
    guardian_sweep(reviews, S, S.mode)


# ------------------------------------------------------------------ tools (used by Investigator + chat)
def _row(ctx, oid):
    m = ctx["df"][ctx["df"]["order_id"] == int(oid)]
    return None if m.empty else m.iloc[0]


def t_get_order(ctx, order_id):
    r = _row(ctx, order_id)
    if r is None:
        return {"error": f"order {order_id} not found"}
    return dict(order_id=int(r["order_id"]), risk=int(r["risk"]), action=r["action"], amount=int(r["amount"]),
                account_age_hrs=float(r["account_age_hrs"]), billing=r["bill_state"], shipping=r["ship_state"],
                orders_10min=int(r["orders_10min"]), ring=r["ring_id"] or None, account=r["account_id"],
                device=r["device_id"], signals=[f"{t} (+{p:.0f})" for t, p, _ in r["reasons"]],
                status=r.get("status", ""))


def t_get_ring(ctx, ring_id):
    sub = ctx["df"][ctx["df"]["ring_id"] == ring_id]
    if sub.empty:
        return {"error": f"ring {ring_id} not found"}
    return dict(ring=ring_id, accounts=int(sub["account_id"].nunique()), orders=len(sub),
                devices=int(sub["device_id"].nunique()), cards=int(sub["card_id"].nunique()),
                total_value=int(sub["amount"].sum()), avg_risk=round(float(sub["risk"].mean()), 1),
                frozen=bool(sub["ring_key"].iloc[0] in ctx["S"].frozen))


def t_device_activity(ctx, device_id):
    sub = ctx["df"][ctx["df"]["device_id"] == device_id]
    return dict(device=device_id, accounts=int(sub["account_id"].nunique()), orders=len(sub),
                sample_accounts=list(sub["account_id"].unique()[:6]))


def t_account_activity(ctx, account_id):
    sub = ctx["df"][ctx["df"]["account_id"] == account_id]
    return dict(account=account_id, orders=len(sub), total_amount=int(sub["amount"].sum()),
                max_risk=int(sub["risk"].max()) if len(sub) else 0)


def t_what_if(ctx, order_id, amount=None, account_age_hrs=None, orders_10min=None, same_state=None):
    r = _row(ctx, order_id)
    if r is None:
        return {"error": f"order {order_id} not found"}
    d = r.drop(_DROP, errors="ignore").to_dict()
    for k, v in dict(amount=amount, account_age_hrs=account_age_hrs, orders_10min=orders_10min).items():
        if v is not None:
            d[k] = v
    if same_state:
        d["ship_state"] = d["bill_state"]
    res = score_frame(pd.DataFrame([d]), ctx["det"], ctx["weights"]).iloc[0]
    return dict(order_id=int(order_id), risk_before=int(r["risk"]), risk_after=int(res["risk"]), action_after=res["action"])


def t_portfolio_stats(ctx):
    df, S = ctx["df"], ctx["S"]
    st_ = df["status"] if "status" in df else pd.Series([""] * len(df))
    return dict(orders=len(df), flagged=int((df["risk"] >= HOLD).sum()), high_risk=int((df["risk"] >= BLOCK).sum()),
                value_flagged=int(df.loc[df["risk"] >= HOLD, "amount"].sum()),
                rings=int(df.loc[df["ring_id"] != "", "ring_id"].nunique()), rings_frozen=len(S.frozen),
                agent_blocked_orders=int(st_.str.startswith("blocked").sum()),
                value_blocked=int(df.loc[st_.str.startswith("blocked"), "amount"].sum()),
                pending_approvals=len(pending(S)), agent_mode=S.mode)


def t_top_orders(ctx, n=5):
    top = ctx["df"].sort_values("risk", ascending=False).head(int(n))
    return [dict(order_id=int(r.order_id), risk=int(r.risk), amount=int(r.amount), ring=r.ring_id or None)
            for r in top.itertuples()]


def t_list_rings(ctx):
    df = ctx["df"]
    g = df[df["ring_id"] != ""].groupby("ring_id").agg(accounts=("account_id", "nunique"), value=("amount", "sum"),
                                                        avg_risk=("risk", "mean")).reset_index()
    return [dict(ring=r.ring_id, accounts=int(r.accounts), value=int(r.value), avg_risk=round(r.avg_risk, 1))
            for r in g.sort_values("value", ascending=False).itertuples()]


def t_review_campaigns(ctx):
    rv = ctx["reviews"]
    bad = rv[rv["campaign"] != ""]
    return [dict(campaign=c, reviews=len(g), accounts=int(g["account"].nunique()),
                 avg_account_age_days=round(float(g["acct_age_days"].mean()), 1)) for c, g in bad.groupby("campaign")]


TOOLS = dict(get_order=t_get_order, get_ring=t_get_ring, device_activity=t_device_activity,
             account_activity=t_account_activity, what_if=t_what_if, portfolio_stats=t_portfolio_stats,
             top_orders=t_top_orders, list_rings=t_list_rings, review_campaigns=t_review_campaigns)


def _spec(name, desc, props=None, req=()):
    return dict(name=name, description=desc,
                input_schema=dict(type="object", properties=props or {}, required=list(req)))


_int, _str, _num = {"type": "integer"}, {"type": "string"}, {"type": "number"}
SPECS = [
    _spec("get_order", "Get one order with its risk score and the signals that fired.", {"order_id": _int}, ["order_id"]),
    _spec("get_ring", "Summarise a fraud ring by id like 'R1'.", {"ring_id": _str}, ["ring_id"]),
    _spec("device_activity", "Which accounts/orders used a device id.", {"device_id": _str}, ["device_id"]),
    _spec("account_activity", "Order history of one account id.", {"account_id": _str}, ["account_id"]),
    _spec("what_if", "Re-score an order with changed attributes to test which evidence drives the flag.",
          {"order_id": _int, "amount": _num, "account_age_hrs": _num, "orders_10min": _num,
           "same_state": {"type": "boolean"}}, ["order_id"]),
    _spec("portfolio_stats", "Overall KPIs: orders, flagged, rings, agent actions, pending approvals."),
    _spec("top_orders", "Highest-risk orders.", {"n": _int}),
    _spec("list_rings", "All detected fraud rings with value at stake."),
    _spec("review_campaigns", "Detected fake-review bot campaigns."),
]
INVESTIGATOR_TOOLS = [s for s in SPECS if s["name"] in
                      ("get_order", "get_ring", "device_activity", "account_activity", "what_if")]


def run_tool(ctx, name, args):
    try:
        return json.dumps(TOOLS[name](ctx, **(args or {})), default=str)
    except Exception as e:  # tools never crash the agent
        return json.dumps({"error": str(e)})


# ------------------------------------------------------------------ live-LLM tool loop (optional)
def llm_loop(system, user, tools, ctx, max_turns=7):
    import anthropic
    client = anthropic.Anthropic()
    model = os.environ.get("TRUSTGUARD_MODEL", "claude-sonnet-4-6")
    messages, trace = [{"role": "user", "content": user}], []
    for _ in range(max_turns):
        resp = client.messages.create(model=model, max_tokens=900, system=system, tools=tools, messages=messages)
        messages.append({"role": "assistant", "content": resp.content})
        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if b.type == "text").strip(), trace
        results = []
        for b in resp.content:
            if b.type == "tool_use":
                out = run_tool(ctx, b.name, b.input)
                trace.append(dict(tool=b.name, args=dict(b.input), result=out))
                results.append({"type": "tool_result", "tool_use_id": b.id, "content": out})
        messages.append({"role": "user", "content": results})
    return "(agent stopped: turn limit reached)", trace


# ------------------------------------------------------------------ Investigator agent
def investigate(oid, ctx, use_llm=True):
    r = _row(ctx, oid)
    if copilot.ai_available() and use_llm:
        try:
            text, trace = llm_loop(
                "You are a fraud investigator agent. Use the tools to gather evidence, then write a concise case file: "
                "verdict, confidence, 3 evidence bullets, recommended action. Never state facts the tools did not return.",
                f"Investigate order #{oid}.", INVESTIGATOR_TOOLS, ctx)
            if trace:
                return dict(oid=oid, verdict="(see report)", confidence=confidence(r), report=text,
                            trace=trace, source="Claude (live tool-use)")
        except Exception:
            pass
    trace = []

    def call(name, **args):
        res = TOOLS[name](ctx, **args)
        trace.append(dict(tool=name, args=args, result=json.dumps(res, default=str)))
        return res

    o = call("get_order", order_id=int(oid))
    ring = call("get_ring", ring_id=r["ring_id"]) if r["ring_id"] else None
    dev = call("device_activity", device_id=r["device_id"]) if r["ring_id"] else None
    acct = call("account_activity", account_id=r["account_id"])
    calm = call("what_if", order_id=int(oid), account_age_hrs=72, orders_10min=1, same_state=True)
    typical = call("what_if", order_id=int(oid), amount=int(ctx["det"].med_amount))

    risk = int(r["risk"])
    verdict = "Likely fraud" if risk >= BLOCK else "Suspicious — needs human review" if risk >= HOLD else "Likely legitimate"
    conf = confidence(r) if risk >= HOLD else round(min(0.99, 0.6 + (HOLD - risk) / 100), 2)
    ev = [f"Engine score **{risk}/100** from {len(o['signals'])} signal(s): " + "; ".join(o["signals"][:3]) + "."]
    if ring:
        ev.append(f"Account sits in **ring {ring['ring']}**: {ring['accounts']} accounts sharing {ring['devices']} devices "
                  f"and {ring['cards']} cards, ₹{ring['total_value']:,} total. This device alone links {dev['accounts']} accounts.")
    ev.append(f"Stress test — removing behavioural signals (older account, one order, matching states): risk "
              f"{risk} → **{calm['risk_after']}**. " +
              ("The flag survives, so it rests on network/payment evidence, not just behaviour."
               if calm["risk_after"] >= HOLD else "The flag depends mainly on behavioural signals."))
    ev.append(f"Normalising the amount to the typical ₹{int(ctx['det'].med_amount):,}: risk → {typical['risk_after']}.")
    ev.append(f"Account activity: {acct['orders']} order(s), ₹{acct['total_amount']:,} total.")
    if ring and risk >= HOLD:
        rec = f"Block this order and freeze ring {ring['ring']} ({ring['accounts']} accounts)."
    elif risk >= BLOCK:
        rec = "Block and send to manual review."
    elif risk >= HOLD:
        rec = "Hold and request step-up verification (OTP/KYC)."
    else:
        rec = "Approve."
    report = f"**Verdict: {verdict}** (confidence {conf:.0%})\n\n" + "\n".join(f"- {e}" for e in ev) + \
             f"\n\n**Recommended action:** {rec}"
    log_agent(ctx["S"], "investigator", "case file", f"order #{oid}", f"{verdict}; {rec}", conf)
    return dict(oid=oid, verdict=verdict, confidence=conf, report=report, trace=trace, source="Rule-based planner")


# ------------------------------------------------------------------ Ask TrustGuard (chat)
def ask(question, ctx):
    if copilot.ai_available():
        try:
            text, _ = llm_loop("You are TrustGuard's analyst assistant. Answer using ONLY tool results. Be concise; "
                               "use ₹ for money.", question, SPECS, ctx)
            return text + "\n\n*— Claude with live tools*"
        except Exception:
            pass
    q = question.lower()
    m = re.search(r"\b(4\d{4})\b", q)
    if m and _row(ctx, m.group(1)) is not None:
        return investigate(int(m.group(1)), ctx)["report"]
    if "ring" in q:
        rs = t_list_rings(ctx)
        return "**Fraud rings** (by value at stake):\n\n" + "\n".join(
            f"- **{r['ring']}** — {r['accounts']} accounts, ₹{r['value']:,}, avg risk {r['avg_risk']}" for r in rs) if rs \
            else "No fraud rings detected."
    if any(w in q for w in ("review", "bot", "campaign")):
        cs = t_review_campaigns(ctx)
        return "**Bot review campaigns:**\n\n" + "\n".join(
            f"- **{c['campaign']}** — {c['reviews']} reviews from {c['accounts']} accounts (avg age {c['avg_account_age_days']} days)"
            for c in cs)
    if any(w in q for w in ("top", "risk", "worst", "highest")):
        return "**Highest-risk orders:**\n\n" + "\n".join(
            f"- #{o['order_id']} — risk {o['risk']}, ₹{o['amount']:,}" + (f", ring {o['ring']}" if o["ring"] else "")
            for o in t_top_orders(ctx, 5))
    if any(w in q for w in ("stat", "how many", "summary", "overview", "agent", "protect", "blocked")):
        s = t_portfolio_stats(ctx)
        return (f"**Overview:** {s['orders']} orders scored, {s['flagged']} flagged ({s['high_risk']} high-risk), "
                f"₹{s['value_flagged']:,} at stake. {s['rings']} rings found, {s['rings_frozen']} frozen. Agents blocked "
                f"{s['agent_blocked_orders']} orders (₹{s['value_blocked']:,}); {s['pending_approvals']} awaiting your approval. "
                f"Agent mode: **{s['agent_mode']}**.")
    return ("I can answer questions like:\n- *Give me an overview*\n- *Show the top risky orders*\n- *Which fraud rings exist?*\n"
            "- *Any bot review campaigns?*\n- *Investigate order 48167*\n\n(Set `ANTHROPIC_API_KEY` for free-form questions.)")


# ------------------------------------------------------------------ executive report
def incident_report(df, reviews, S):
    flagged = df[df["risk"] >= HOLD]
    blocked = df[df["status"].str.startswith("blocked")]
    rings = df[df["ring_id"] != ""].groupby("ring_id").agg(accounts=("account_id", "nunique"), value=("amount", "sum"))
    lines = [f"# TrustGuard Incident Report", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", "",
             "## Summary", f"- Orders scored: **{len(df)}**", f"- Flagged: **{len(flagged)}** "
             f"(₹{int(flagged['amount'].sum()):,} at stake)", f"- Blocked by agents/analysts: **{len(blocked)}** "
             f"(₹{int(blocked['amount'].sum()):,} protected)", f"- Fraud rings: **{len(rings)}**, frozen: **{len(S.frozen)}**",
             f"- Bot-review campaigns: **{reviews['campaign'].replace('', pd.NA).nunique()}**, "
             f"taken down: **{len(S.takedowns)}**", f"- Agent mode: **{S.mode}**", "", "## Fraud rings"]
    lines += [f"- {r}: {int(v.accounts)} accounts, ₹{int(v.value):,}" for r, v in rings.iterrows()] or ["- none"]
    lines += ["", "## Top 5 orders"] + [f"- #{o['order_id']}: risk {o['risk']}, ₹{o['amount']:,}" for o in t_top_orders({"df": df}, 5)]
    lines += ["", "## Agent activity"] + ([f"- {a['time']} {a['agent']} — {a['action']}: {a['target']}"
                                          for a in S.agent_log[-20:]] or ["- none"])
    return "\n".join(lines)

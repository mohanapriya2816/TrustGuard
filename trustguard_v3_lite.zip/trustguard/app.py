"""TrustGuard v3 - agentic fraud, fraud-ring & fake-review defence. Run: streamlit run app.py"""
import hmac
import os
import random
import time
from datetime import datetime

import pandas as pd
import streamlit as st

import agents
import copilot
import redteam
from data_gen import STATES, attack_orders, make_orders, make_reviews, new_orders
from risk_engine import (BLOCK, DEFAULT_WEIGHTS, HOLD, RULE_NAMES, W_MAX, W_MIN, Detector, analyze,
                         counterfactual, flag_reviews, ring_dot, score_frame)

st.set_page_config(page_title="TrustGuard", page_icon="🛡️", layout="wide")
ss = st.session_state

# ================================================================ Admin login (constant-time compare + lockout)
ss.setdefault("auth", False)
ss.setdefault("tries", 0)
ss.setdefault("locked_until", 0.0)
if not ss.auth:
    st.title("🛡️ TrustGuard Admin")
    wait = ss.locked_until - time.time()
    if wait > 0:
        st.error(f"Too many failed attempts. Try again in {int(wait) + 1}s.")
        st.stop()
    pw = st.text_input("Admin password", type="password")
    st.caption("Demo password: `admin123` — set the ADMIN_PASSWORD env var for real deployments.")
    if st.button("Login"):
        if hmac.compare_digest(pw.encode(), os.environ.get("ADMIN_PASSWORD", "admin123").encode()):
            ss.auth, ss.tries = True, 0
            st.rerun()
        ss.tries += 1
        if ss.tries >= 5:
            ss.locked_until, ss.tries = time.time() + 30, 0
        st.error("Wrong password")
    st.stop()


# ================================================================ State
def reset():
    ss.orders = make_orders()
    ss.detector = Detector(ss.orders)          # ML baseline = "normal" traffic
    ss.weights = dict(DEFAULT_WEIGHTS)         # learnable rule weights
    ss.decisions, ss.audit = {}, []
    ss.next_id = int(ss.orders["order_id"].max()) + 1
    ss.stream = False
    agents.init_state(ss)                      # agent queue, guardrails, logs, frozen rings...


if "orders" not in ss:
    reset()


@st.cache_data
def reviews_df():
    return flag_reviews(make_reviews())


def log(kind, target, detail):
    ss.audit.append(dict(time=datetime.now().strftime("%H:%M:%S"), action=kind, target=target, detail=detail))


def feedback(oid, label, reasons):
    """Analyst feedback loop: confirming fraud strengthens the rules that fired; a false positive weakens them."""
    ss.decisions[oid] = label
    for _, _, k in reasons:
        delta = 1.5 if label == "fraud" else -2.5
        ss.weights[k] = min(W_MAX, max(W_MIN, ss.weights[k] + delta))
    log("confirm fraud" if label == "fraud" else "false positive", f"order #{oid}",
        ", ".join(RULE_NAMES[k] for _, _, k in reasons) or "no rules fired")


def full_analysis():
    """Score everything, let the agents act (per current mode), and attach each order's status."""
    t = time.perf_counter()
    df = analyze(ss.orders, ss.detector, ss.weights)
    latency = (time.perf_counter() - t) * 1000
    agents.run_all(agents.with_status(df, ss), reviews_df(), ss)
    return agents.with_status(df, ss), latency


# ================================================================ Sidebar
with st.sidebar:
    st.header("🤖 Agent mode")
    modes = ["Off", "Suggest", "Autopilot"]
    ss.mode = st.radio("Agent mode", modes, index=modes.index(ss.mode), horizontal=True,
                       label_visibility="collapsed",
                       help="Off: agents idle • Suggest: agents queue actions for you • Autopilot: agents act within guardrails")
    st.caption({"Off": "Agents are idle.", "Suggest": "Agents propose; **you** approve.",
                "Autopilot": "Agents act on their own inside guardrails."}[ss.mode])
    with st.expander("🚧 Guardrails"):
        ss.guard["min_conf"] = st.slider("Min confidence to act alone", 0.70, 0.99, 0.85, step=0.01, key="g_conf")
        ss.guard["max_auto"] = st.slider("Max auto-actions per sweep", 1, 30, 10, key="g_auto")
        ss.guard["ring_cap"] = st.slider("Max ₹ an agent may freeze alone", 100000, 2000000, 1000000,
                                         step=50000, key="g_cap")
    st.divider()
    st.header("🎯 Attack Simulator")
    st.caption("Fire a coordinated card-testing attack and watch the squad react.")
    if st.button("🚨 Launch attack", type="primary", use_container_width=True):
        new = attack_orders(ss.next_id)
        ss.next_id += len(new)
        ss.orders = pd.concat([ss.orders, new], ignore_index=True)
        log("attack simulated", f"{len(new)} orders", "new fraud ring injected")
        st.toast("🚨 Coordinated attack detected — a new fraud ring has been linked!", icon="🚨")
    ss.stream = st.toggle("▶ Live order stream", value=ss.stream, help="New orders arrive every 2 seconds")
    if st.button("Reset demo data", use_container_width=True):
        reset()
        st.rerun()
    st.divider()
    min_risk = st.slider("Show orders with risk ≥", 0, 100, 50)
    st.caption(f"LLM features: **{'Claude connected' if copilot.ai_available() else 'offline mode (rule-based agents)'}**")
    if st.button("Logout"):
        ss.auth = False
        st.rerun()

st.title("🛡️ TrustGuard")
st.caption("Agentic trust & safety: detect → explain → act → learn. Every flag has a reason; every agent has guardrails.")
tab1, tab_ag, tab2, tab3, tab4, tab5 = st.tabs(
    ["📊 Live Dashboard", "🤖 Agent Squad", "🔍 Explain & What-If", "🕸️ Fraud Rings", "📝 Fake Reviews", "🧠 Learning & Audit"])

orders, ms = full_analysis()
view = orders[orders["risk"] >= min_risk].sort_values("risk", ascending=False)


# ================================================================ Tab 1: live dashboard (auto-refreshing fragment)
def live_view():
    if ss.stream:
        new = new_orders(ss.next_id, n=random.randint(1, 3))
        ss.next_id += len(new)
        ss.orders = pd.concat([ss.orders, new], ignore_index=True).tail(3000)
    df, latency = full_analysis()
    flagged = df[df["risk"] >= HOLD]
    shown = df[df["risk"] >= min_risk].sort_values("risk", ascending=False)
    protected = df[df["status"].str.startswith("blocked")]
    c = st.columns(6)
    c[0].metric("Orders scored", len(df))
    c[1].metric("Flagged (≥ 50)", len(flagged))
    c[2].metric("High risk (≥ 75)", int((df["risk"] >= BLOCK).sum()))
    c[3].metric("₹ flagged", f"₹{int(flagged['amount'].sum()):,}")
    c[4].metric("Fraud rings", df.loc[df["ring_id"] != "", "ring_id"].nunique())
    c[5].metric("₹ blocked", f"₹{int(protected['amount'].sum()):,}")
    tp = int(flagged["is_fraud"].sum())
    st.caption(f"⚡ Scored {len(df)} orders (rules + ML + ring graph) in {latency:.0f} ms"
               f"  •  Precision {tp / max(1, len(flagged)):.0%} / Recall {tp / max(1, int(df['is_fraud'].sum())):.0%} "
               f"on synthetic ground truth  •  🤖 agents: **{ss.mode}**" + ("  •  🟢 LIVE" if ss.stream else ""))
    left, right = st.columns(2)
    with left:
        st.subheader("Flagged orders over time")
        st.line_chart(flagged.set_index("created_at").resample("30min").size().rename("flagged"))
    with right:
        st.subheader("Where flagged orders ship to")
        geo = flagged["ship_state"].value_counts().rename_axis("state").reset_index(name="n")
        if not geo.empty:
            geo["lat"] = geo["state"].map(lambda s: STATES[s][0])
            geo["lon"] = geo["state"].map(lambda s: STATES[s][1])
            geo["size"] = geo["n"] * 15000
            st.map(geo, latitude="lat", longitude="lon", size="size", height=300)
    st.subheader(f"Orders to review ({len(shown)})")
    st.dataframe(shown[["order_id", "risk", "action", "status", "amount", "bill_state", "ship_state", "ring_id", "why"]],
                 hide_index=True, column_config={
                     "risk": st.column_config.ProgressColumn("risk", min_value=0, max_value=100, format="%d"),
                     "amount": st.column_config.NumberColumn("amount", format="₹%d")})
    st.download_button("⬇ Export flagged orders (CSV)",
                       shown.drop(columns=["reasons"]).to_csv(index=False), "trustguard_flagged.csv")


with tab1:
    st.fragment(run_every=2 if ss.stream else None)(live_view)()

# ================================================================ Tab 2: AGENT SQUAD
with tab_ag:
    ctx = dict(df=orders, det=ss.detector, weights=ss.weights, reviews=reviews_df(), S=ss)
    st.markdown("A squad of specialised agents works the queue alongside you. Each one is **explainable**, "
                "**bounded by guardrails**, and logs every action. Flip the sidebar to **Autopilot** to watch them work.")
    counts = pd.Series([a["agent"] for a in ss.agent_log]).value_counts()
    cards = [("triage", "Decides on flagged orders: auto-block when confident, escalate when signals disagree."),
             ("ring", "Hunts linked accounts and freezes whole rings (capped by ₹ value)."),
             ("guardian", "Finds bot-review campaigns. Content removal always needs a human."),
             ("investigator", "Tool-using agent: gathers evidence and writes a case file."),
             ("red", "Attacks our own detector, then patches the gaps it finds.")]
    for col, (key, blurb) in zip(st.columns(5), cards):
        with col:
            st.markdown(f"**{agents.AGENTS[key]}**")
            st.caption(blurb)
            st.metric("actions", int(counts.get(agents.AGENTS[key], 0)))

    # ---- approval queue
    queue = agents.pending(ss)
    st.subheader(f"✋ Human approval queue ({len(queue)})")
    if not queue:
        st.info("Nothing waiting. Set the agent mode to **Suggest** or **Autopilot** in the sidebar.")
    for p in queue[:8]:
        with st.container(border=True):
            q1, q2, q3 = st.columns([5, 1, 1])
            q1.markdown(f"**{agents.AGENTS[p['agent']]}** — {p['title']}  \n"
                        f"<small>{p['detail']} • confidence {p['conf']:.0%}</small>", unsafe_allow_html=True)
            if q2.button("✅ Approve", key=f"ap{p['id']}"):
                agents.execute(ss, p, True)
                st.rerun()
            if q3.button("❌ Reject", key=f"rj{p['id']}"):
                agents.execute(ss, p, False)
                st.rerun()
    if len(queue) > 8:
        st.caption(f"…and {len(queue) - 8} more.")

    # ---- live agent feed
    st.subheader("📡 Live agent feed")

    def feed_view():
        if ss.agent_log:
            st.dataframe(pd.DataFrame(ss.agent_log[::-1][:40]), hide_index=True, column_config={
                "confidence": st.column_config.ProgressColumn("confidence", min_value=0, max_value=1, format="%.2f")})
        else:
            st.caption("No agent activity yet.")

    st.fragment(run_every=3 if ss.stream else None)(feed_view)()

    # ---- investigator
    st.subheader("🔬 Investigator Agent")
    st.caption("Watch it choose tools, gather evidence and reach a verdict. "
               + ("Powered by Claude tool-use." if copilot.ai_available() else
                  "Running its built-in planner (set ANTHROPIC_API_KEY to let Claude drive the tools)."))
    cand = list(view["order_id"].head(30)) or list(orders.sort_values("risk", ascending=False)["order_id"].head(30))
    inv_oid = st.selectbox("Order to investigate", cand, key="inv_oid")
    if st.button("🔎 Run investigation"):
        ss.investigation = agents.investigate(int(inv_oid), ctx)
    inv = ss.investigation
    if inv:
        st.markdown(f"##### Case file — order #{inv['oid']}  ·  _{inv['source']}_")
        for i, step in enumerate(inv["trace"], 1):
            args = ", ".join(f"{k}={v}" for k, v in step["args"].items())
            st.markdown(f"**{i}. `{step['tool']}`**({args})")
            st.caption(step["result"][:260])
        st.markdown(inv["report"])

    # ---- red team vs blue team
    st.subheader("⚔️ Red Team vs Blue Team")
    st.caption("Red invents attacks built to slip past our rules. Blue tests patch rules against those attacks "
               "and against normal traffic, and only recommends patches that don't flood analysts with false alarms.")
    if st.button("⚔️ Run red-team drill"):
        ss.redteam = redteam.drill(ss.detector, ss.weights)
    rt = ss.redteam
    if rt:
        res = pd.DataFrame({"Detected today": rt["before"], "After Blue-Team patches": rt["after"]})
        res.index.name = "Attack strategy"
        st.bar_chart(res)
        st.dataframe(pd.DataFrame([dict(strategy=k, how=v, detected_today=f"{rt['before'][k]:.0%}",
                                        after_patches=f"{rt['after'][k]:.0%}") for k, v in rt["strategies"].items()]),
                     hide_index=True)
        st.markdown("**Blue Team patch candidates** (each tested on every attack *and* on 500 normal orders):")
        st.dataframe(pd.DataFrame([dict(
            patch=p["name"], closes_gap_in=p["best_for"], detection_gain=f"+{p['uplift']:.0%}",
            false_alarms=f"{p['fp_delta']:+.1%}", verdict=("✅ deploy" if p["recommended"] else "❌ reject — " + p["why"]))
            for p in rt["patches"]]), hide_index=True)
        rec = [p["rule"] for p in rt["patches"] if p["recommended"]]
        if rec and st.button(f"🛠️ Deploy {len(rec)} recommended patch(es)"):
            for k in rec:
                ss.weights[k] = redteam.PATCH_WEIGHT
            log("patches deployed", ", ".join(rec), "Blue Team, validated against red-team drill")
            agents.log_agent(ss, "red", "deployed patches", ", ".join(RULE_NAMES[k] for k in rec),
                             f"false alarms {rt['fp_before']:.1%} → {rt['fp_after']:.1%}")
            ss.redteam = None
            st.rerun()
        elif not rec:
            st.success("All known evasion strategies are already covered.")

    # ---- chat
    st.subheader("💬 Ask TrustGuard")
    for role, text in ss.chat:
        st.chat_message(role).markdown(text)
    q = st.chat_input("Ask about orders, rings, reviews, or agent activity…")
    if q:
        ss.chat += [("user", q), ("assistant", agents.ask(q, ctx))]
        agents.log_agent(ss, "chat", "answered", q[:60], "")
        st.rerun()

    st.download_button("📄 Download incident report (Markdown)", agents.incident_report(orders, reviews_df(), ss),
                       "trustguard_incident_report.md")

# ================================================================ Tab 3: explain, what-if, case note, feedback
with tab2:
    if view.empty:
        st.info("No orders match the current filter.")
    else:
        oid = st.selectbox("Pick a flagged order", view["order_id"])
        row = orders[orders["order_id"] == oid].iloc[0]
        a, b = st.columns([1, 2])
        a.metric("Risk score", row["risk"])
        a.progress(int(row["risk"]) / 100)
        a.markdown(f"**Recommended action:** {row['action']}")
        if row["status"]:
            a.markdown(f"**Status:** {row['status']}")
        with b:
            st.markdown(f"### Why order #{oid} was flagged")
            if row["reasons"]:
                for text, pts, _ in row["reasons"]:
                    st.markdown(f"- {text} **(+{pts:.0f})**")
                st.bar_chart(pd.DataFrame([(t, p) for t, p, _ in row["reasons"]],
                                          columns=["rule", "points"]).set_index("rule"))
            else:
                st.success("No risk signals fired.")

        need = counterfactual(row["risk"], row["reasons"])
        if need:
            st.info("**Counterfactual:** this order would drop below the review threshold if it did NOT have: "
                    + " + ".join(f"*{t}* (−{p:.0f})" for t, p in need))

        st.markdown("#### 🧪 What-if simulator")
        st.caption("Change the order's attributes and watch the risk score and decision recompute live.")
        w1, w2, w3, w4 = st.columns(4)
        amt = w1.slider("Amount (₹)", 200, 60000, int(row["amount"]), key=f"wa{oid}")
        age = w2.slider("Account age (hrs)", 0.0, 500.0, float(min(row["account_age_hrs"], 500)), key=f"wg{oid}")
        vel = w3.slider("Orders in 10 min", 1, 6, int(row["orders_10min"]), key=f"wv{oid}")
        same = w4.toggle("Billing = shipping state", value=row["bill_state"] == row["ship_state"], key=f"ws{oid}")
        d = row.drop(["reasons", "action", "why", "risk", "ml_pct", "ml_note", "status"]).to_dict()
        d.update(amount=amt, account_age_hrs=age, orders_10min=vel)
        if same:
            d["ship_state"] = d["bill_state"]
        elif d["ship_state"] == d["bill_state"]:
            d["ship_state"] = next(s for s in STATES if s != d["bill_state"])
        res = score_frame(pd.DataFrame([d]), ss.detector, ss.weights).iloc[0]
        st.metric("Simulated risk", res["risk"], delta=int(res["risk"] - row["risk"]), delta_color="inverse")
        st.caption(f"Decision would be: **{res['action']}**")

        st.markdown("#### 🤖 Analyst case note")
        if st.button("Generate case note", key=f"note{oid}"):
            text, src = copilot.case_note(row)
            st.write(text)
            st.caption(f"Source: {src}")

        st.markdown("#### ✅ Your verdict teaches the system")
        if oid in ss.decisions:
            st.success(f"Already marked as **{'confirmed fraud' if ss.decisions[oid] == 'fraud' else 'false positive'}**.")
        else:
            f1, f2, _ = st.columns([1, 1, 3])
            if f1.button("🚫 Confirm fraud", key=f"cf{oid}"):
                feedback(oid, "fraud", row["reasons"])
                st.rerun()
            if f2.button("👍 False positive", key=f"fp{oid}"):
                feedback(oid, "fp", row["reasons"])
                st.rerun()

# ================================================================ Tab 4: fraud rings
with tab3:
    rings = (orders[orders["ring_id"] != ""].groupby("ring_id")
             .agg(ring_key=("ring_key", "first"), accounts=("account_id", "nunique"), orders=("order_id", "size"),
                  devices=("device_id", "nunique"), cards=("card_id", "nunique"),
                  total_value=("amount", "sum"), avg_risk=("risk", "mean")).reset_index()
             .sort_values("accounts", ascending=False))
    st.markdown("Fraudsters hide behind many accounts — but they reuse **devices and cards**. "
                "TrustGuard links accounts through those shared fingerprints and exposes the whole network.")
    if rings.empty:
        st.success("No fraud rings detected.")
    else:
        rings["avg_risk"] = rings["avg_risk"].round(0)
        rings["frozen"] = rings["ring_key"].isin(ss.frozen)
        st.dataframe(rings.drop(columns="ring_key"), hide_index=True, column_config={
            "total_value": st.column_config.NumberColumn("total value", format="₹%d")})
        rid = st.selectbox("Inspect a ring", rings["ring_id"])
        info = rings[rings["ring_id"] == rid].iloc[0]
        m = st.columns(4)
        m[0].metric("Linked accounts", int(info["accounts"]))
        m[1].metric("Shared devices", int(info["devices"]))
        m[2].metric("Shared cards", int(info["cards"]))
        m[3].metric("Value at stake", f"₹{int(info['total_value']):,}")
        st.graphviz_chart(ring_dot(orders, rid), use_container_width=True)
        st.caption("🔴 blocked account  🟠 held  🟢 approved  •  🔷 device  •  🟣 card")
        if info["frozen"]:
            st.success(f"Ring {rid} is frozen.")
        elif st.button(f"🧊 Freeze all {int(info['accounts'])} accounts in {rid}"):
            ss.frozen.add(info["ring_key"])
            log("ring frozen", rid, f"{int(info['accounts'])} accounts, ₹{int(info['total_value']):,}")
            st.rerun()

# ================================================================ Tab 5: fake reviews
with tab4:
    reviews = reviews_df()
    bad = reviews[reviews["suspicious"]]
    c = st.columns(4)
    c[0].metric("Reviews scanned", len(reviews))
    c[1].metric("Suspicious reviews", len(bad))
    c[2].metric("Bot campaigns", bad["campaign"].nunique())
    c[3].metric("Campaigns removed", len(ss.takedowns))
    st.caption("Signals: TF-IDF text similarity + posting-burst timing + account age → grouped into coordinated campaigns. "
               "Review Guardian proposes takedowns in the Agent Squad tab.")
    bad = bad.assign(status=bad["campaign"].map(lambda c: "removed" if c in ss.takedowns else ""))
    st.dataframe(bad[["review_id", "campaign", "status", "account", "text", "risk", "reason"]]
                 .sort_values("risk", ascending=False), hide_index=True, column_config={
                     "risk": st.column_config.ProgressColumn("risk", min_value=0, max_value=100, format="%d")})

# ================================================================ Tab 6: learning + audit
with tab5:
    st.markdown("### 🧠 The engine learns")
    st.caption("Analyst verdicts nudge rule weights (+1.5 / −2.5). Blue-Team patches switch on new rules once proven.")
    wdf = pd.DataFrame({"rule": [RULE_NAMES[k] for k in DEFAULT_WEIGHTS],
                        "default": list(DEFAULT_WEIGHTS.values()),
                        "learned": [ss.weights[k] for k in DEFAULT_WEIGHTS]}).set_index("rule")
    st.bar_chart(wdf)
    n_f = sum(v == "fraud" for v in ss.decisions.values())
    d = st.columns(3)
    d[0].metric("Decisions made", len(ss.decisions))
    d[1].metric("Confirmed fraud", n_f)
    d[2].metric("False positives", len(ss.decisions) - n_f)
    st.markdown("### 📜 Audit trail")
    if ss.audit:
        adf = pd.DataFrame(ss.audit)
        st.dataframe(adf, hide_index=True)
        st.download_button("⬇ Download audit log (CSV)", adf.to_csv(index=False), "trustguard_audit.csv")
    else:
        st.info("No analyst actions yet — confirm a fraud, mark a false positive, launch an attack, or freeze a ring.")

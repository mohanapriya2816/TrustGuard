# 🛡️ TrustGuard v3 — Agentic Fraud, Fraud-Ring & Fake-Review Defence

**Detect → Explain → Act → Learn → and now: a squad of AI agents that works the queue with you.**

> **LITE build:** uses only `streamlit`, `pandas` and `numpy`. The Isolation Forest and the TF-IDF text-similarity
> are implemented from scratch in numpy (`risk_engine.py`), so the app runs on locked-down Windows laptops where
> Application Control / Smart App Control blocks `scipy` / `scikit-learn`.

## Run it (2 minutes)
```bash
cd trustguard
python -m pip install -r requirements.txt
python -m streamlit run app.py
```
Open http://localhost:8501 — password `admin123` (override: `ADMIN_PASSWORD=yourpass`).

**Optional upgrades** (the demo works fully without them):
| Env var | Effect |
|---|---|
| `ANTHROPIC_API_KEY` (+ `pip install anthropic`) | Investigator and chat switch from the built-in planner to live Claude tool-use; case notes written by Claude |
| `SLACK_WEBHOOK_URL` | Agents post alerts to Slack on auto-blocks / auto-frozen rings |
| `TRUSTGUARD_MODEL` | Override the Claude model name |

## 🤖 The Agent Squad (new)
| Agent | What it does | Autonomy |
|---|---|---|
| 🧭 **Triage Agent** | Scores confidence from *how many independent signal families agree*; auto-blocks clear-cut orders, escalates ambiguous ones | Acts alone in Autopilot above the confidence guardrail, rate-limited by a circuit breaker |
| 🕸️ **Ring Hunter** | Finds linked accounts and freezes whole rings | Acts alone only if the ring's ₹ value is under the cap; bigger rings need human sign-off |
| 📝 **Review Guardian** | Proposes removing bot-review campaigns | **Always** needs a human (content removal is never automatic) |
| 🔬 **Investigator** | Picks tools, gathers evidence, runs stress-tests, writes a case file — with a visible step-by-step trace | Advisory |
| ⚔️ **Red Team / Blue Team** | Red invents 4 evasion attacks that slip past the rules (0% detected); Blue tests patch rules against those attacks **and** 500 normal orders and deploys only the safe ones | Human clicks Deploy |
| 💬 **Ask TrustGuard** | Chat over live data: overview, top orders, rings, campaigns, "investigate order 48167" | Read-only |

**Agent modes** (sidebar): **Off** · **Suggest** (agents queue everything for approval) · **Autopilot** (agents act inside guardrails).
**Guardrails** (sidebar): minimum confidence, max auto-actions per sweep (circuit breaker), max ₹ an agent may freeze alone.
Every agent action lands in the live feed, the audit trail and the downloadable incident report.

## Everything else (from v2)
Fraud-ring graph · Isolation-Forest ML with top-feature explanations · what-if simulator + counterfactuals ·
analyst feedback that re-weights rules · live order stream · attack simulator · fake-review campaigns ·
geo map · precision/recall scorecard · audit trail + CSV export · hardened login (constant-time compare, lockout).

## 4-minute demo script
1. **Dashboard** — "600 orders scored in ~90 ms, precision/recall shown against ground truth." Toggle **▶ Live order stream**.
2. Sidebar → **🚨 Launch attack**. A new ring appears; agents are still **Off**, so nothing is handled yet.
3. Flip **Agent mode → Autopilot**. Open **🤖 Agent Squad**: watch the feed — rings frozen, orders auto-blocked, *circuit breaker* throttling at 10 per sweep, bot campaign waiting in the approval queue.
4. Say: *"It never removes reviews or freezes huge rings by itself"* — drag **Max ₹ an agent may freeze alone** down to 100k and show the ring jump back into the human queue.
5. **🔬 Run investigation** on the top order — walk through the trace: ring lookup, device sharing, stress test ("flag survives, so it rests on network evidence").
6. **⚔️ Run red-team drill** — "we attacked ourselves: 4 strategies, 0% detected." Show Blue Team's table: 4 patches deployed, one **rejected** because it adds 3.6% false alarms. Click **Deploy** → drill again → coverage up.
7. **💬 Ask TrustGuard**: *"Give me an overview"* → "agents blocked N orders, ₹X protected."
8. Download the **incident report**. Close: *"Detect, Explain, Act, Learn — and defend itself."*

## Files
- `app.py` – Streamlit dashboard (6 tabs, sidebar agent controls)
- `agents.py` – agent squad, tools, LLM tool-loop, chat, incident report
- `redteam.py` – evasion-attack generator + patch evaluator
- `risk_engine.py` – rules (incl. dormant patch rules), Isolation Forest, ring graph, review detection
- `copilot.py` – analyst case notes
- `data_gen.py` – synthetic orders (3 hidden rings + ground-truth labels), attack/stream generators, bot reviews

## Deploy
Push to GitHub → https://share.streamlit.io → main file `app.py`; add env vars under *Secrets*.

## Honest limitations (say these out loud — judges respect it)
- All data is synthetic; precision/recall are measured on that synthetic ground truth, not real traffic.
- Red-team strategies and Blue-team patch candidates are a hand-designed library; the agent's job is to *measure and select*, not invent new rule shapes.
- Without an API key, the Investigator and chat are deterministic planners (same tools, scripted order). The live-Claude path uses the standard tool-use loop but was not exercised against the live API during development.
- State lives in Streamlit session memory; production would use a database/queue (Postgres + Kafka/Redis).
